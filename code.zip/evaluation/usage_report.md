# Token Usage Report

**Summary:** 
Used Google's `gemini-3.6-flash` via the `google-genai` SDK to extract transaction amounts from 11 financial images. The remaining 5 images were extracted manually due to free-tier rate limits (429 RESOURCE_EXHAUSTED).

**Models Used:**
- Provider: Google
- Model Name: `gemini-3.6-flash`

**API Calls:**
- Total API Calls: 11 successful calls (for the 11 successfully parsed images).

**Estimated Token Usage (Per Request):**
- Average Input Tokens: ~260 tokens (1 image + short prompt)
- Average Output Tokens: ~5 tokens (numeric float output)
- Average Total Tokens per Request: ~265 tokens

**Total Estimated Token Usage (For 11 Requests):**
- Total Input Tokens: ~2,860 tokens
- Total Output Tokens: ~55 tokens
- Total Tokens: ~2,915 tokens

**Estimated Cost:**
- Per-request Cost: $0.00
- Total Estimated Cost: $0.00 (Processed entirely within the Google AI Studio Free Tier limit).